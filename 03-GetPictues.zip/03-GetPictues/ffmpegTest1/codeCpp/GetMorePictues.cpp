//
//  GetMorePictues.cpp
//  ffmpegTest1
//
//  Created by 德志 on 2019/1/25.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

#include "GetMorePictues.hpp"


AVFormatContext *inputContext = nullptr;
AVFormatContext * outputContext;

AVCodecContext * enCodecContext = nullptr;
AVCodecContext * inputCodeContex = nullptr;

int64_t lastReadPacktTime ;

static int interrupt_cb(void *ctx)
{
    int  timeout  = 3;
    if(av_gettime() - lastReadPacktTime > timeout *1000 *1000)
    {
        return -1;
    }
    return 0;
}


int OpenInput(string inputUrl)
{
    inputContext = avformat_alloc_context();
    lastReadPacktTime = av_gettime();
    inputContext->interrupt_callback.callback = interrupt_cb;
    int ret = avformat_open_input(&inputContext, inputUrl.c_str(), nullptr,nullptr);
    if(ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "Input file open input failed\n");
        return  ret;
    }
    ret = avformat_find_stream_info(inputContext,nullptr);
    if(ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "Find input file stream inform failed\n");
    }
    else
    {
        av_log(NULL, AV_LOG_FATAL, "Open input file  %s success\n",inputUrl.c_str());
    }

    for (int i = 0; i < inputContext->nb_streams; i++) {
        if (inputContext ->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO) {
            inputCodeContex = inputContext->streams[i]->codec;
        }
    }
    return ret;
}


shared_ptr<AVPacket> ReadPacketFromSource()
{
    shared_ptr<AVPacket> packet(static_cast<AVPacket*>(av_malloc(sizeof(AVPacket))), [&](AVPacket *p) { av_packet_free(&p); av_freep(&p);});
    av_init_packet(packet.get());
    lastReadPacktTime = av_gettime();
    int ret = av_read_frame(inputContext, packet.get());
    if(ret >= 0)
    {
        return packet;
    }
    else
    {
        return nullptr;
    }
}


void initEncoderCodec(AVStream* inputStream)
{
    AVCodec *  picCodec;
    picCodec = avcodec_find_encoder(AV_CODEC_ID_MJPEG);
    enCodecContext = avcodec_alloc_context3(picCodec);
    enCodecContext->codec_id = picCodec->id;
    enCodecContext->time_base.num = 1;
    enCodecContext->time_base.den = 25;
    enCodecContext->pix_fmt =  *picCodec->pix_fmts;
    enCodecContext->width = inputStream->codec->width;
    enCodecContext->height =inputStream->codec->height;
}


void EncoderCodec()
{

    // 构建一个新stream
    AVStream* pAVStream = avformat_new_stream(outputContext, 0);
    if( pAVStream == NULL )
    {
        return;
    }
    // 设置该stream的信息
    enCodecContext = pAVStream->codec;
    enCodecContext->codec_id = outputContext->oformat->video_codec;
    enCodecContext->codec_type = AVMEDIA_TYPE_VIDEO;
    enCodecContext->pix_fmt = AV_PIX_FMT_YUVJ420P;
    enCodecContext->width = inputCodeContex->width;
    enCodecContext->height = inputCodeContex->height;
    enCodecContext->time_base.num = 1;
    enCodecContext->time_base.den = 25;
}


void Init()
{
    av_register_all();
    avfilter_register_all();
    avformat_network_init();
    av_log_set_level(AV_LOG_WARNING);
}

void CloseInput()
{
    if(inputContext != nullptr)
    {
        avformat_close_input(&inputContext);
    }
}

void CloseOutput()
{
    if(outputContext != nullptr)
    {
        int ret = av_write_trailer(outputContext);
        for(int i = 0 ; i < outputContext->nb_streams; i++)
        {
            AVCodecContext *codecContext = outputContext->streams[i]->codec;
            avcodec_close(codecContext);
        }
        avformat_close_input(&outputContext);
    }
}


void colseWriteCodec(){
    if(outputContext)
    {
        for(int i = 0; i < outputContext->nb_streams; i++)
        {
            avcodec_close(outputContext->streams[i]->codec);
        }
        avformat_close_input(&outputContext);
    }
}

int WritePacket(shared_ptr<AVPacket> packet,string outUrl)
{

    AVCodec * decode = avcodec_find_decoder(inputCodeContex->codec_id);
    int ret = avcodec_open2(inputCodeContex,decode,nullptr);
    if (ret < 0) {
        av_log(NULL, AV_LOG_ERROR, "decode open fail");
        colseWriteCodec();
        return -1;
    }

    AVFrame * frame = av_frame_alloc();
    int got_picture = 0;
    ret = avcodec_decode_video2(inputCodeContex,frame,&got_picture,packet.get());
    if (ret < 0  && got_picture == 0) {
        av_log(NULL, AV_LOG_ERROR, "decode fail");
        colseWriteCodec();
        return -1;
    }

    outputContext = avformat_alloc_context();
    outputContext->oformat = av_guess_format("mjpeg",NULL,NULL);
    ret =avio_open(&outputContext->pb, outUrl.c_str(), AVIO_FLAG_READ_WRITE);;
    if(ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "open avio failed");
        colseWriteCodec();
        return -1;
    }

    EncoderCodec();
    av_dump_format(outputContext, 0, outUrl.c_str(), 1);
    AVCodec * encodec = avcodec_find_encoder(enCodecContext->codec_id);
    ret = avcodec_open2(enCodecContext,encodec,nullptr);
    if (ret < 0) {
        av_log(NULL, AV_LOG_ERROR, "find encodec fail");
        colseWriteCodec();
        return -1;
    }

    ret = avformat_write_header(outputContext, nullptr);
    if(ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "format write header failed");
        colseWriteCodec();
        return -1;
    }

    got_picture = 0;
    AVPacket * tmppacket =  av_packet_alloc();
    ret = avcodec_encode_video2(enCodecContext,tmppacket,frame,&got_picture);
    if (ret < 0  && got_picture == 0) {
        av_log(NULL, AV_LOG_ERROR, "encode fail");
        colseWriteCodec();
        return -1;
    }

    av_log(NULL, AV_LOG_FATAL, " Open output file success %s\n",outUrl.c_str());
    av_write_frame(outputContext, tmppacket);
    av_write_trailer(outputContext);
    return 1;

}

int InitDecodeContext(AVStream *inputStream)
{
    auto codecId = inputStream->codec->codec_id;
    auto codec = avcodec_find_decoder(codecId);
    if (!codec)
    {
        return -1;
    }

    int ret = avcodec_open2(inputStream->codec, codec, NULL);
    return ret;

}


void allclose(){
    CloseInput();
    CloseOutput();
    while(true)
    {
        this_thread::sleep_for(chrono::seconds(100));
    }
}

void startfunc()
{
    Init();
    int ret = OpenInput("rtsp://admin:passwrod@192.168.1.101:554/h264/ch1/main/av_stream");
    int packetnumber = 0;
    while(packetnumber  < 100 )
    {
        packetnumber ++;
        auto packet = ReadPacketFromSource();
        if(packet)
        {
            auto s = std::to_string(packetnumber);
            string path =  "/Users/wudezhi/Desktop/videoData/image/"+s+".jpg";
            ret = WritePacket(packet,path.c_str());
        }
    }
    cout <<"Get Picture End "<<endl;
    avcodec_close(enCodecContext);
}
