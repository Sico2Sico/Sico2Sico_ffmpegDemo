//
//  GetMorePictues.hpp
//  ffmpegTest1
//
//  Created by 德志 on 2019/1/25.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

#ifndef GetMorePictues_hpp
#define GetMorePictues_hpp

#include <stdio.h>
#include <string>
#include <memory>
#include <thread>
#include <iostream>

using namespace std;
void startfunc();
#endif /* GetMorePictues_hpp */
