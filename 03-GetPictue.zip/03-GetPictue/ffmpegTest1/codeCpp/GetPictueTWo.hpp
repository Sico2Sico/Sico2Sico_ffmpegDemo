//
//  GetPictueTWo.hpp
//  ffmpegTest1
//
//  Created by 德志 on 2019/1/24.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

#ifndef GetPictueTWo_hpp
#define GetPictueTWo_hpp

#include <stdio.h>
int appStart();

#endif /* GetPictueTWo_hpp */
