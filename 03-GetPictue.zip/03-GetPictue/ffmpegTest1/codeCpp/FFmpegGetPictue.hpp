//
//  FFmpegGetPictue.hpp
//  ffmpegTest1
//
//  Created by 德志 on 2019/1/23.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

#ifndef FFmpegGetPictue_hpp
#define FFmpegGetPictue_hpp

#include <stdio.h>
#include <string>
#include <memory>
#include <thread>
#include <iostream>

using namespace std;
void startfunc();
#endif /* FFmpegGetPictue_hpp */
