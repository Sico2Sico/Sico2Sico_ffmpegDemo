//
//  ViewController.m
//  ffmpegTest1
//
//  Created by 德志 on 2019/1/19.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

#import "ViewController.h"
//#include "GetPictueTWo.hpp"
#include "GetMorePictues.hpp"
#import <VideoToolbox/VideoToolbox.h>
#import <AudioToolbox/AudioToolbox.h>

@interface ViewController ()

@end


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    startfunc();
}




@end
