//
//  ViewController.h
//  ffmpegTest1
//
//  Created by 德志 on 2019/1/19.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ViewController : UIViewController



@end

