//
//  GCSaveFile.hpp
//  ffmpegTest1
//
//  Created by 德志 on 2019/1/19.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

#ifndef GCSaveFile_hpp
#define GCSaveFile_hpp

#include <stdio.h>
#include <string>
#include <memory>
#include <thread>
#include <iostream>

using namespace std;

int OpenInput(string inputUrl);
shared_ptr<AVPacket> ReadPacketFromSource();
int OpenOutput(string outurl);
void CloseInput();
void CloseOutput();
void Init();
int WritePacket(shared_ptr<AVPacket> packet);

#endif /* GCSaveFile_hpp */
