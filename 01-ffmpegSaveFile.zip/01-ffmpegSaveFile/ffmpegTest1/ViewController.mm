//
//  ViewController.m
//  ffmpegTest1
//
//  Created by 德志 on 2019/1/19.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

#import "ViewController.h"
#include "GCSaveFile.hpp"
#import <VideoToolbox/VideoToolbox.h>
#import <AudioToolbox/AudioToolbox.h>

@interface ViewController ()

@end


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    NSString*path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject;

    path = [path stringByAppendingPathComponent:@"test.mp4"];

    Init();
    int ret = OpenInput("rtmp://192.168.1.100:1935/rtmplive/room");
    if (ret >= 0) {
        ret = OpenOutput(path.cString);
    }

    while (true) {
        auto packet = ReadPacketFromSource();
        if (packet) {
            ret = WritePacket(packet);
//            if (ret => 0) {
//                cout << "写入成功" << endl;
//            }else{
//                cout<<"WritePacket failed!"<<endl;
//            }

        }
    }

}


@end
