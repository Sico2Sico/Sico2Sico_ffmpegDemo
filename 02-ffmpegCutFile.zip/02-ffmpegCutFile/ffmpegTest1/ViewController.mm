//
//  ViewController.m
//  ffmpegTest1
//
//  Created by 德志 on 2019/1/19.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

#import "ViewController.h"
#include "FFMpegCutFile.hpp"
#import <VideoToolbox/VideoToolbox.h>
#import <AudioToolbox/AudioToolbox.h>

@interface ViewController ()

@end


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];


    int startPacketNum = 500;
    int discardtPacketNum = 200;

    int packetCount = 0;

    int64_t lastPacketPts = AV_NOPTS_VALUE;
    int64_t lastPtS = AV_NOPTS_VALUE;

    Init();

    int ret = openInput("/Users/wudezhi/Desktop/videoData/ffmpeg.flv");

    if (ret >= 0 ) {
        NSString*path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject;
        path = [path stringByAppendingPathComponent:@"test.flv"];
        ret = OpenOutput(path.cString);
    }

    if (ret < 0) {
        CloseInput();
        CloseOutput();
        while(true)
        {
            this_thread::sleep_for(chrono::seconds(100));
        }
    }

    BOOL isTrue = YES;
    while (isTrue) {
        auto packet = ReadPacketFromSource();
        if (packet) {
            packetCount++;
            cout << " packetCount ==  "  << packetCount << endl;
//            if (packetCount <= 46696 || packetCount >= 700) {
                if (packetCount >= 30000) {
                    if (packet->pts -lastPacketPts > 120) {
                        lastPtS = lastPacketPts;
                    }else{
                        auto diff = packet->pts -lastPacketPts;
                        lastPtS += diff;
                    }
                    lastPacketPts = packet->pts;
                    if (lastPtS != AV_NOPTS_VALUE) {
                        packet->pts = packet->dts = lastPtS;
                    }
                    ret = WritePacket(packet);
                }
//            }
        }else{
            isTrue = FALSE;
            cout << "Cut File End" << endl;
            CloseInput();
            CloseOutput();
        }
    }
}




@end
