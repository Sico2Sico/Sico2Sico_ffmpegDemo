//
//  FFMpegCutFile.cpp
//  ffmpegTest1
//
//  Created by 德志 on 2019/1/22.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

#include "FFMpegCutFile.hpp"

AVFormatContext * inputCts = nullptr;
AVFormatContext * outputCts = nullptr;
AVFrame * frame = nullptr;

int64_t lastReadPacketTime = 0;

static int interrupt_cb(void *ctx){
    int timeout = 3;
    if (av_gettime() - lastReadPacketTime > timeout*1000*1000) {
        return  -1;
    }
    return  0;
}


int openInput(string inputUrl){

    inputCts = avformat_alloc_context();
    lastReadPacketTime = av_gettime();

    inputCts->interrupt_callback.callback = interrupt_cb;
    int ret = avformat_open_input(&inputCts,inputUrl.c_str(),nullptr, nullptr);

    if (ret  < 0) {
        av_log(NULL, AV_LOG_ERROR, "Input file open input failed\n");
        return  ret;
    }

    ret = avformat_find_stream_info(inputCts,nullptr);
    if(ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "Find input file stream inform failed\n");
    }
    else
    {
        av_log(NULL, AV_LOG_FATAL, "Open input file  %s success\n",inputUrl.c_str());
    }
    return ret;
}

shared_ptr<AVPacket> ReadPacketFromSource(){
    shared_ptr<AVPacket> packet(static_cast<AVPacket*>(av_malloc(sizeof(AVPacket))), [&](AVPacket *p) { av_packet_free(&p); av_freep(&p);});

    av_init_packet(packet.get());
    int ret = av_read_frame(inputCts,packet.get());
    lastReadPacketTime = av_gettime();
    if (ret >= 0) {
        return packet;
    }else{
        return nullptr;
    }
}


int OpenOutput(string outUrl)
{
    int ret  = avformat_alloc_output_context2(&outputCts, nullptr, "flv", outUrl.c_str());
    if(ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "open output context failed\n");
        goto Error;
    }

    ret = avio_open2(&outputCts->pb, outUrl.c_str(), AVIO_FLAG_WRITE,nullptr, nullptr);
    if(ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "open avio failed");
        goto Error;
    }

    for(int i = 0; i < inputCts->nb_streams; i++)
    {
        AVStream * stream = avformat_new_stream(outputCts, inputCts->streams[i]->codec->codec);
        ret = avcodec_copy_context(stream->codec, inputCts->streams[i]->codec);
        if(ret < 0)
        {
            av_log(NULL, AV_LOG_ERROR, "copy coddec context failed");
            goto Error;
        }
    }

    ret = avformat_write_header(outputCts, nullptr);
    if(ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "format write header failed");
        goto Error;
    }

    av_log(NULL, AV_LOG_FATAL, " Open output file success %s\n",outUrl.c_str());
    return ret ;
Error:
    if(outputCts)
    {
        for(int i = 0; i < outputCts->nb_streams; i++)
        {
            avcodec_close(outputCts->streams[i]->codec);
        }
        avformat_close_input(&outputCts);
    }
    return ret ;
}


void Init() {
    av_register_all();
    avfilter_register_all();
    avformat_network_init();
    av_log_set_level(AV_LOG_ERROR);
}


void CloseInput(){
    if (inputCts != nullptr) {
        avformat_close_input(&inputCts);
    }
}


void CloseOutput(){
    if (outputCts != nullptr) {
        for(int i = 0 ; i < outputCts->nb_streams; i++){
            AVCodecContext *code = outputCts->streams[i]->codec;
            avcodec_close(code);
        }
        avformat_close_input(&outputCts);
    }
}


int WritePacket(shared_ptr<AVPacket> packet){
    auto inputStream = inputCts ->streams[packet->stream_index];
    auto outputStream = outputCts->streams[packet->stream_index];
    av_packet_rescale_ts(packet.get(),inputStream->time_base,outputStream->time_base);
    return  av_interleaved_write_frame(outputCts,packet.get());
}





