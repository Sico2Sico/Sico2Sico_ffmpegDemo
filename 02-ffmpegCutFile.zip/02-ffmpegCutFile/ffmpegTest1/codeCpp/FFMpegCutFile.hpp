//
//  FFMpegCutFile.hpp
//  ffmpegTest1
//
//  Created by 德志 on 2019/1/22.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

#ifndef FFMpegCutFile_hpp
#define FFMpegCutFile_hpp

#include <stdio.h>
#include <string>
#include <memory>
#include <thread>
#include <iostream>
using namespace std;

void Init();
int openInput(string inputUrl);
int OpenOutput(string outUrl);

shared_ptr<AVPacket> ReadPacketFromSource();
int WritePacket(shared_ptr<AVPacket> packet);

void CloseInput();
void CloseOutput();

#endif /* FFMpegCutFile_hpp */
